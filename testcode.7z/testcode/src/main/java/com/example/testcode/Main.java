package com.example.testcode;

public class Main {

    public static void main(String[] args) {
        RemoveLetter.remove("aabcccbbad");
        System.out.println("===================");
        InsteadLetter.instead("abcccbad");
    }


}
